# UnESCaped – Loading Screen
## Android Studio Integration Guide

---

### 📁 File Structure

```
app/src/main/
├── java/com/skjallheim/unescaped/
│   └── LoadingActivity.java          ← Main loading screen logic
├── res/
│   ├── layout/
│   │   └── activity_loading.xml      ← Loading screen layout
│   ├── drawable/
│   │   ├── anim_robber_run.xml       ← Robber sprite animation list
│   │   ├── anim_viking_run.xml       ← Viking sprite animation list
│   │   ├── robber_run_00.png         ← Robber frames (00–11)
│   │   ├── viking_run_00.png         ← Viking frames (00–11)
│   │   ├── bg_layer_far.png          ← Background far layer
│   │   ├── bg_layer_near.png         ← Background near layer
│   │   ├── progress_loading_bar.xml  ← Gold progress bar style
│   │   ├── ember_shape.xml           ← Ember particle circle
│   │   ├── divider_gold.xml          ← Gold gradient divider line
│   │   ├── corner_tl/tr/bl/br.xml   ← Progress bar corner brackets
│   │   ├── bg_wanted_badge.xml       ← WANTED stamp background
│   │   ├── bg_subtitle_banner.xml    ← Kingdom subtitle banner
│   │   ├── bg_ground_strip.xml       ← Ground gradient strip
│   │   ├── vignette_overlay.xml      ← Screen edge darkening
│   │   └── fog_overlay.xml           ← Top/bottom atmospheric fog
│   ├── anim/
│   │   ├── anim_panel_enter.xml      ← Centre panel fade-in slide
│   │   ├── anim_title_pulse.xml      ← Title glow pulse loop
│   │   ├── anim_wanted_pulse.xml     ← WANTED badge alpha pulse
│   │   └── anim_ember_float.xml      ← Ember rise animation
│   └── values/
│       ├── colors.xml                ← All brand colors
│       ├── strings.xml               ← All text + loading tips array
│       ├── dimens.xml                ← Character position offsets
│       └── themes.xml                ← App + Loading screen themes
└── AndroidManifest.xml               ← Manifest snippet
```

---

### 🚀 Setup Steps

**1. Copy all files into your Android Studio project.**
   - Java file → `app/src/main/java/com/skjallheim/unescaped/`
   - All `res/` folders → merge with your existing `app/src/main/res/`
   - PNG assets → `app/src/main/res/drawable/`

**2. Update your AndroidManifest.xml.**
   Copy the `<activity>` blocks from the provided `AndroidManifest.xml`.
   Make sure `LoadingActivity` has the `LAUNCHER` intent filter.

**3. Set the screen orientation to landscape.**
   The game is landscape-only. The manifest already sets `android:screenOrientation="landscape"`.

**4. Add AppCompat dependency** (if not already in build.gradle):
   ```groovy
   dependencies {
       implementation 'androidx.appcompat:appcompat:1.6.1'
   }
   ```

---

### 🎮 Connecting Real Loading Progress

The loading bar is **simulated by default** (random increments).
To drive it from real asset loading, use the public API:

```java
// In whatever thread loads your assets:
loadingActivity.setProgress(25);   // 25% done
loadingActivity.setProgress(50);   // half way
loadingActivity.setProgress(75);   // almost there
loadingActivity.setProgress(100);  // triggers transition to game
```

Or call `finishLoading()` directly when all assets are ready.

---

### 🔀 Transition to Game

In `LoadingActivity.java`, find `finishLoading()` and uncomment:
```java
Intent intent = new Intent(LoadingActivity.this, MainActivity.class);
startActivity(intent);
overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
finish();
```

Replace `MainActivity.class` with your actual game Activity class name.

---

### 🎨 Customisation

| What                  | Where                                |
|-----------------------|--------------------------------------|
| Loading tip messages  | `res/values/strings.xml`             |
| Brand colors          | `res/values/colors.xml`              |
| Progress bar style    | `res/drawable/progress_loading_bar.xml` |
| Robber position       | `res/values/dimens.xml` → `robber_x_offset` |
| Viking position       | `res/values/dimens.xml` → `viking_x_offset` |
| Ember spawn rate      | `EMBER_SPAWN_INTERVAL_MS` in Java    |
| Parallax speed        | `BG_FAR_SPEED` / `BG_NEAR_SPEED` in Java |
| Animation speed       | Duration values in `anim_*.xml`      |

---

### 📝 Notes

- The Viking sprites face **left** (`Left - Running`) so they appear to chase Kael who faces right.
- The `"ES"` in the title is styled crimson+italic via `SpannableString` in Java — this highlights the hidden "ESCape" in the game title.
- Background images use `scaleType="centerCrop"` and are translated for the parallax scroll. The images are wide enough to loop seamlessly.
- Ember particles are real `View` objects added/removed from `ember_container` — no Canvas drawing needed.
