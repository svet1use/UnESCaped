package com.skjallheim.unescaped;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.util.Random;

/**
 * LoadingActivity
 *
 * The loading screen for UnESCaped.
 *
 * Features:
 *  - Parallax scrolling background (two layers at different speeds)
 *  - Kael (Robber) running animation using AnimationDrawable
 *  - Viking pursuer running animation using AnimationDrawable
 *  - Animated progress bar with gold shimmer + rotating loading tips
 *  - Ember particle system (Views added/removed dynamically)
 *  - WANTED badge with pulse animation
 *  - Title "UnESCaped" with "ES" highlighted in crimson via SpannableString
 *  - Panel fade-in entrance animation
 *
 * Usage:
 *  Set this as your launcher Activity in AndroidManifest.xml.
 *  When loading is complete, call finishLoading() to transition to MainActivity.
 */
public class LoadingActivity extends AppCompatActivity {

    // ── UI REFERENCES ────────────────────────────────────────────────────────
    private ImageView imgBgFar;
    private ImageView imgBgNear;
    private ImageView imgRobber;
    private ImageView imgViking;
    private FrameLayout emberContainer;
    private TextView tvTitle;
    private TextView tvLoadingLabel;
    private TextView tvProgressPct;
    private TextView tvWanted;
    private ProgressBar progressBar;
    private View panelContainer;

    // ── STATE ────────────────────────────────────────────────────────────────
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Random random = new Random();
    private int currentProgress = 0;
    private int currentTipIndex = 0;
    private boolean isFinished = false;

    // Parallax scroll offsets (in px), updated every frame
    private float bgFarOffset = 0f;
    private float bgNearOffset = 0f;

    // Loading tips shown at progress milestones
    private String[] loadingTips;

    // Timing constants
    private static final int PROGRESS_INTERVAL_MS  = 80;   // how often progress ticks
    private static final int EMBER_SPAWN_INTERVAL_MS = 200; // ember spawn rate
    private static final int BG_SCROLL_INTERVAL_MS  = 16;   // ~60fps scroll
    private static final float BG_FAR_SPEED  = 0.6f;        // px per frame, far layer
    private static final float BG_NEAR_SPEED = 1.4f;        // px per frame, near layer

    // ── LIFECYCLE ────────────────────────────────────────────────────────────

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Fullscreen immersive
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
        );
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );

        setContentView(R.layout.activity_loading);

        bindViews();
        loadingTips = getResources().getStringArray(R.array.loading_tips);

        setupTitle();
        startPanelEntranceAnimation();
        startCharacterAnimations();
        startParallaxScroll();
        startEmberSystem();
        startProgressSimulation();
        startWantedBadgeAnimation();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Resume sprite animations
        if (imgRobber.getDrawable() instanceof AnimationDrawable) {
            ((AnimationDrawable) imgRobber.getDrawable()).start();
        }
        if (imgViking.getDrawable() instanceof AnimationDrawable) {
            ((AnimationDrawable) imgViking.getDrawable()).start();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Stop sprite animations to save battery
        if (imgRobber.getDrawable() instanceof AnimationDrawable) {
            ((AnimationDrawable) imgRobber.getDrawable()).stop();
        }
        if (imgViking.getDrawable() instanceof AnimationDrawable) {
            ((AnimationDrawable) imgViking.getDrawable()).stop();
        }
        // Remove all pending callbacks
        handler.removeCallbacksAndMessages(null);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
    }

    // ── SETUP ────────────────────────────────────────────────────────────────

    /** Bind all view references. */
    private void bindViews() {
        imgBgFar        = findViewById(R.id.bg_layer_far);
        imgBgNear       = findViewById(R.id.bg_layer_near);
        imgRobber       = findViewById(R.id.img_robber);
        imgViking       = findViewById(R.id.img_viking);
        emberContainer  = findViewById(R.id.ember_container);
        tvTitle         = findViewById(R.id.tv_title);
        tvLoadingLabel  = findViewById(R.id.tv_loading_label);
        tvProgressPct   = findViewById(R.id.tv_progress_pct);
        tvWanted        = findViewById(R.id.tv_wanted);
        progressBar     = findViewById(R.id.progress_bar);
        panelContainer  = findViewById(R.id.panel_container);
    }

    /**
     * Style the title "UnESCaped":
     *  - "Un"     → gold
     *  - "ES"     → crimson + italic (the hidden "ESCape" visual)
     *  - "Caped"  → gold
     */
    private void setupTitle() {
        String full = "UnESCaped";
        SpannableString spannable = new SpannableString(full);

        int goldColor   = ContextCompat.getColor(this, R.color.medieval_gold);
        int crimsonColor = ContextCompat.getColor(this, R.color.blood_red);

        // "ES" spans indices 2–4
        spannable.setSpan(
                new ForegroundColorSpan(crimsonColor),
                2, 4,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        );
        spannable.setSpan(
                new StyleSpan(android.graphics.Typeface.BOLD_ITALIC),
                2, 4,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        );

        // Rest is gold (default text colour handles this, but set explicitly for safety)
        spannable.setSpan(new ForegroundColorSpan(goldColor), 0, 2,  Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        spannable.setSpan(new ForegroundColorSpan(goldColor), 4, full.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

        tvTitle.setText(spannable);
    }

    // ── ANIMATIONS ───────────────────────────────────────────────────────────

    /** Fade + slide-up the centre panel on first load. */
    private void startPanelEntranceAnimation() {
        Animation panelEnter = AnimationUtils.loadAnimation(this, R.anim.anim_panel_enter);
        panelContainer.startAnimation(panelEnter);

        // Title pulse (looping, starts after entrance)
        handler.postDelayed(() -> {
            Animation titlePulse = AnimationUtils.loadAnimation(this, R.anim.anim_title_pulse);
            tvTitle.startAnimation(titlePulse);
        }, 1200);
    }

    /** Start sprite AnimationDrawables for Robber and Viking. */
    private void startCharacterAnimations() {
        // Must call start() after the view is drawn
        imgRobber.post(() -> {
            if (imgRobber.getDrawable() instanceof AnimationDrawable) {
                ((AnimationDrawable) imgRobber.getDrawable()).start();
            }
        });
        imgViking.post(() -> {
            if (imgViking.getDrawable() instanceof AnimationDrawable) {
                ((AnimationDrawable) imgViking.getDrawable()).start();
            }
        });
    }

    /** WANTED badge pulsing alpha animation. */
    private void startWantedBadgeAnimation() {
        Animation pulse = AnimationUtils.loadAnimation(this, R.anim.anim_wanted_pulse);
        tvWanted.startAnimation(pulse);
    }

    // ── PARALLAX BACKGROUND SCROLL ───────────────────────────────────────────

    /**
     * Scrolls bg_layer_far and bg_layer_near at different speeds
     * to create a parallax depth effect.
     *
     * We translate the ImageViews left continuously.
     * When offset exceeds half the image width, we reset to 0 (seamless loop).
     * The images are centerCrop so they always fill the screen.
     */
    private void startParallaxScroll() {
        handler.post(scrollRunnable);
    }

    private final Runnable scrollRunnable = new Runnable() {
        @Override
        public void run() {
            bgFarOffset  += BG_FAR_SPEED;
            bgNearOffset += BG_NEAR_SPEED;

            // Reset when we've scrolled one full image width (seamless loop)
            float farWidth  = imgBgFar.getWidth();
            float nearWidth = imgBgNear.getWidth();
            if (farWidth  > 0 && bgFarOffset  > farWidth)  bgFarOffset  -= farWidth;
            if (nearWidth > 0 && bgNearOffset > nearWidth) bgNearOffset -= nearWidth;

            imgBgFar.setTranslationX(-bgFarOffset);
            imgBgNear.setTranslationX(-bgNearOffset);

            handler.postDelayed(this, BG_SCROLL_INTERVAL_MS);
        }
    };

    // ── PROGRESS BAR ─────────────────────────────────────────────────────────

    /**
     * Simulates loading progress.
     * In a real game, replace the random increment with actual asset-loading callbacks.
     */
    private void startProgressSimulation() {
        handler.post(progressRunnable);
    }

    private final Runnable progressRunnable = new Runnable() {
        @Override
        public void run() {
            if (isFinished) return;

            // Random increment between 1–3%
            int increment = 1 + random.nextInt(3);
            currentProgress = Math.min(100, currentProgress + increment);

            // Animate progress bar smoothly
            ObjectAnimator progressAnim = ObjectAnimator.ofInt(
                    progressBar, "progress", progressBar.getProgress(), currentProgress
            );
            progressAnim.setDuration(PROGRESS_INTERVAL_MS);
            progressAnim.start();

            tvProgressPct.setText(currentProgress + "%");

            // Update loading tip at each 12.5% milestone
            int tipThreshold = (currentTipIndex + 1) * (100 / loadingTips.length);
            if (currentProgress >= tipThreshold && currentTipIndex < loadingTips.length - 1) {
                tvLoadingLabel.setText(loadingTips[currentTipIndex]);
                currentTipIndex++;
            }

            if (currentProgress >= 100) {
                tvLoadingLabel.setText(loadingTips[loadingTips.length - 1]);
                handler.postDelayed(() -> finishLoading(), 800);
            } else {
                handler.postDelayed(this, PROGRESS_INTERVAL_MS);
            }
        }
    };

    /**
     * Called when loading is complete.
     * Replace the TODO with your Intent to MainActivity or GameActivity.
     */
    private void finishLoading() {
        if (isFinished) return;
        isFinished = true;

        // Fade out the entire screen
        View root = findViewById(R.id.root_loading);
        root.animate()
                .alpha(0f)
                .setDuration(600)
                .withEndAction(() -> {
                    // TODO: Start your main activity
                    // Intent intent = new Intent(LoadingActivity.this, MainActivity.class);
                    // startActivity(intent);
                    // overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                    // finish();
                })
                .start();
    }

    // ── EMBER PARTICLE SYSTEM ────────────────────────────────────────────────

    /**
     * Spawns small glowing circular Views that float upward like embers/sparks.
     * Each ember has a randomised:
     *  - start X position
     *  - size (4–10dp)
     *  - color (blood red / ember orange / gold)
     *  - upward drift speed
     *  - horizontal drift
     */
    private void startEmberSystem() {
        // Spawn initial batch immediately
        for (int i = 0; i < 12; i++) {
            handler.postDelayed(this::spawnEmber, random.nextInt(2000));
        }
        // Continuous spawn
        handler.post(emberSpawnRunnable);
    }

    private final Runnable emberSpawnRunnable = new Runnable() {
        @Override
        public void run() {
            spawnEmber();
            handler.postDelayed(this, EMBER_SPAWN_INTERVAL_MS + random.nextInt(150));
        }
    };

    private void spawnEmber() {
        // Size in dp → px
        float density = getResources().getDisplayMetrics().density;
        int sizeDp = 4 + random.nextInt(7);   // 4–10dp
        int sizePx = (int) (sizeDp * density);

        // Pick a random ember color
        int[] emberColors = {
                ContextCompat.getColor(this, R.color.blood_red),
                ContextCompat.getColor(this, R.color.ember_orange),
                ContextCompat.getColor(this, R.color.medieval_gold),
        };
        int color = emberColors[random.nextInt(emberColors.length)];

        // Create the ember View
        View ember = new View(this);
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(sizePx, sizePx);
        ember.setLayoutParams(params);
        ember.setBackgroundResource(R.drawable.ember_shape);
        ember.getBackground().setTint(color);
        ember.setAlpha(0f);

        // Random X position
        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        float startX = random.nextFloat() * screenWidth;
        ember.setX(startX);

        // Start at the bottom of the screen
        int screenHeight = getResources().getDisplayMetrics().heightPixels;
        ember.setY(screenHeight);

        emberContainer.addView(ember);

        // Animate upward + fade in then out
        float driftX = (random.nextFloat() - 0.5f) * 80 * density;
        long duration = 3000 + random.nextInt(2000);

        ember.animate()
                .translationYBy(-screenHeight * 1.2f)
                .translationXBy(driftX)
                .scaleX(0.3f)
                .scaleY(0.3f)
                .alpha(0f)
                .setDuration(duration)
                .setStartDelay(0)
                .withStartAction(() -> ember.animate().alpha(0.9f).setDuration(300).start())
                .withEndAction(() -> emberContainer.removeView(ember))
                .start();
    }

    // ──────────────────────────────────────────────────────────────────────────
    //  PUBLIC API — call these from your actual asset-loading logic
    // ──────────────────────────────────────────────────────────────────────────

    /**
     * Set the exact progress value (0–100).
     * Use this instead of the simulated progress when you have real loading callbacks.
     *
     * Example:
     *   loadingActivity.setProgress(33);   // after loading level 1 assets
     *   loadingActivity.setProgress(66);   // after loading level 2 assets
     *   loadingActivity.setProgress(100);  // done
     */
    public void setProgress(int progress) {
        handler.post(() -> {
            currentProgress = Math.min(100, Math.max(0, progress));
            progressBar.setProgress(currentProgress);
            tvProgressPct.setText(currentProgress + "%");
            if (currentProgress >= 100) {
                handler.postDelayed(this::finishLoading, 500);
            }
        });
    }
}
